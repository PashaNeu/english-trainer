# English Phrases Trainer (Simple)

Single-file site. Deploy anywhere (Netlify Drop, GitHub Pages).
